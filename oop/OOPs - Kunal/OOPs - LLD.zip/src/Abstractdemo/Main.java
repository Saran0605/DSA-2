package Abstractdemo;

public class Main {
    public static void main(String[] args) {
        Son saran = new Son();
        saran.career("Coder");
        //we cant just directly create object for abstract classes
        // Parent mom = new Parent();
    }
}
