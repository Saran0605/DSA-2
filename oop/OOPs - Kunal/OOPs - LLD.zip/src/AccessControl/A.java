package AccessControl;

public class A {
    int num;
    String name;
    int[] arr;

    public A(int num, String name, int[] arr) {
        this.num = num;
        this.name = name;
        this.arr = arr;
    }
}
