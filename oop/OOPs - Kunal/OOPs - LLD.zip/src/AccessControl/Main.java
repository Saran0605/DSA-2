package AccessControl;

public class Main {
    public static void main(String[] args) {
        A obj = new A(23,"saran",new int[88]);

    }
}
