package ComparingObj;

public class Main {
    public static void main(String[] args) {
        Student saran = new Student(90,87.5f);
        Student kunal = new Student(88,90.7f);

    }
}
