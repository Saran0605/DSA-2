package Encapsulation;

public class Lang {
    String name;
    private int api;


    public void setApi(int n){//setter function
        this.api = n;
    }

    public int getApi(){//getter function
        return api;
    }
}
