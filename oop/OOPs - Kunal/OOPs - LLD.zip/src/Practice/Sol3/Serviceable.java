package Practice.Sol3;

public interface Serviceable {
    public void service();
}
