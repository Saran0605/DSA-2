package cloning;

public class A {
}
