package oop2;

public class Main {
    public static void main(String[] args) {
        Human saran = new Human(20,"saran",25000,false);
        Human swetha = new Human(23,"swetha",30000,false);
        System.out.println(Human.population);
    }
}
