package polymorphism;

public class Circle extends  Shapes{
    void area(){
        System.out.println("iam in Circle");
    }


}
