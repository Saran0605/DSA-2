package polymorphism;

public class Main {
    public static void main(String[] args) {
//        Shapes shapes = new Shapes();
//        Circle circle = new Circle();
//        Shapes square = new Square();
//        shapes.area();
//        square.area();//method overriding

//        Shapes.greeting();
//        Circle ci = new Circle();
//        ci.greeting();//static methods wont override
//    }

    }
}
