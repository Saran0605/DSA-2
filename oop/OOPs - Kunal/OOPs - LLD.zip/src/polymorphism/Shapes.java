package polymorphism;

  public class Shapes {
     void area(){
        System.out.println("iam in shapes");
    }
//    static void greeting(){
//        System.out.println("Iam in shapes greeting");
//    }
}
