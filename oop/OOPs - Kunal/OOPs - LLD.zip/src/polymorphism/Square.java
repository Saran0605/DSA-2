package polymorphism;

public class Square extends Shapes{
    void area(){
        System.out.println("iam in Square");
    }
}
