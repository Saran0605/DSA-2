package polymorphism;

public class Triangle extends  Shapes{
    void area(){
        System.out.println("iam in Triangle");
    }
}
